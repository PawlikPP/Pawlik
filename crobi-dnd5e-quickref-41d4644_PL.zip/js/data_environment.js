data_environment_obscurance = [
    {
        title: "Lekkie zaciemnienie",
        icon: "bleeding-eye",
        subtitle: "Wada postrzegania",
        description: "Przyćmione światło, mgła, umiarkowane ulistnienie",
        reference: "PHB, pg. 183.",
        bullets: [
            "Stworzenia mają <b>niekorzystny wpływ na testy Mądrości (Percepcji)</b>, które opierają się na wzroku."
        ]
    },
    {
        title: "Mocne zaciemnienie",
        icon: "lightning-tear",
        subtitle: "Skutecznie ślepy",
        description: "Ciemność, nieprzejrzysta mgła, gęste liście",
        reference: "PHB, pg. 183.",
        bullets: [
            "Istota znajdująca się w mocno zasłoniętym obszarze skutecznie cierpi na <b>warunek oślepienia</b>."
        ]
    }
]

data_environment_light = [
    {
        title: "Jasne światło",
        icon: "star-pupil",
        subtitle: "Normalne widzenie",
        description: "Jasne światło pozwala większości stworzeń widzieć normalnie",
        reference: "PHB, pg. 183.",
        bullets: [
            "Ponure dni nadal zapewniają jasne światło, podobnie jak pochodnie, latarnie, ogniska i inne źródła oświetlenia w określonym promieniu."
        ]
    },
    {
        title: "Przyćmione światło",
        icon: "semi-closed-eye",
        subtitle: "Lekkie zaciemnienie",
        description: "Przyćmione światło, zwane również cieniem",
        reference: "PHB, pg. 183.",
        bullets: [
            "Tworzy <b>lekko zaciemniony</b> obszar.",
            "Obszar przyćmionego światła jest zwykle granicą między źródłem jasnego światła, takim jak pochodnia, a otaczającą ciemnością.",
            "Miękkie światło zmierzchu i świtu również liczy się jako przyćmione światło. Szczególnie wspaniała pełnia księżyca może skąpać ziemię w słabym świetle."
        ]
    },
    {
        title: "Mrok",
        icon: "worried-eyes",
        subtitle: "Mocne zaciemnienie",
        description: "Ciemność tworzy mocno zaciemniony obszar",
        reference: "PHB, pg. 183.",
        bullets: [
            "Tworzy <b>mocno zaciemniony</b> obszar.",
            "Postacie muszą stawić czoła ciemności na zewnątrz w nocy (nawet w większość księżycowych nocy), w nieoświetlonym lochu lub podziemnym skarbcu lub w obszarze magicznej ciemności."
        ]
    }
]

data_environment_vision = [
    {
        title: "Ślepowidzenie",
        icon: "one-eyed",
        subtitle: "Postrzeganie bez wzroku",
        description: "Dostrzeganie otoczenia bez polegania na wzroku, w określonym promieniu.",
        reference: "PHB, pg. 183.",
        bullets: [
            "Zmysł ten posiadają stworzenia bez oczu, takie jak muły, oraz stworzenia z echolokacją lub wyostrzonymi zmysłami, takie jak nietoperze i prawdziwe smoki."
        ]
    },
    {
        title: "Widzenie w ciemności",
        icon: "semi-closed-eye",
        subtitle: "Ograniczone widzenie w ciemności",
        description: "Istota posiadająca zdolność widzenia w ciemności może lepiej widzieć w ciemności lub przy słabym oświetleniu, w określonym promieniu.",
        reference: "PHB, pgs. 183-184.",
        bullets: [
            "W określonym zasięgu, istota posiadająca zdolność widzenia w ciemności może <b>widzieć w ciemności tak, jakby ciemność była przyćmionym światłem</b>, więc obszary ciemności są tylko lekko przesłonięte, jeśli chodzi o tę istotę.",
            "Istota ta nie jest jednak w stanie dostrzec kolorów w ciemności, a jedynie odcienie szarości.",
            "Wiele stworzeń w światach D&D, zwłaszcza tych zamieszkujących podziemia, posiada zdolność widzenia w ciemności."
        ]
    },
    {
        title: "Prawdziwe spojrzenie",
        icon: "eye-shield",
        subtitle: "Widzenie w ciemności",
        description: "Istota z jasnowidzeniem widzi wszystko w swojej prawdziwej formie, niezależnie od otoczenia",
        reference: "PHB, pg. 184.",
        bullets: [
            "Istota z prawdziwym wzrokiem może, w określonym zakresie, widzieć w normalnej i magicznej ciemności, widzieć niewidzialne istoty i przedmioty, automatycznie wykrywać iluzje wizualne i odnosić sukcesy w rzutach obronnych przeciwko nim, a także dostrzega oryginalną formę zmiennokształtnego lub istoty, która została przekształcona przez magię.",
            "Co więcej, istota ta może widzieć do Płaszczyzny Eterycznej."
        ]
    }
]

data_environment_cover = [
    {
        title: "Połowa zasłony",
        icon: "broken-shield",
        subtitle: "Niska ściana, meble, stworzenia",
        description: "Cel ma połowę osłony, jeśli przeszkoda blokuje co najmniej połowę jego ciała.",
        reference: "PHB, pg. 196.",
        bullets: [
            "Przeszkodą może być niska ściana, duży mebel, wąski pień drzewa lub stworzenie, niezależnie od tego, czy jest wrogiem, czy przyjacielem.",
            "Cel z połową osłony otrzymuje premię <b>+2 do AC i rzutów obronnych na Zręczność</b>.",
            " Jeśli cel znajduje się za kilkoma źródłami osłony, zastosowanie ma tylko najbardziej ochronny stopień osłony"
        ]
    },
    {
        title: "Zasłona trzy czwarte",
        icon: "cracked-shield",
        subtitle: "Baszta, szczelina na strzałę",
        description: "Cel ma trzy czwarte osłony, jeśli około trzy czwarte jego powierzchni jest zasłonięte przez przeszkodę.",
        reference: "PHB, pg. 196.",
        bullets: [
            "The obstacle might be a portcullis, an arrow slit, or a thick tree trunk.",
            "Przeszkodą może być kratownica, szczelina na strzałę lub gruby pień drzewa.",
            " Jeśli cel znajduje się za kilkoma źródłami osłony, zastosowanie ma tylko najbardziej ochronny stopień osłony"
        ]
    },
    {
        title: "Pełna zasłona",
        icon: "shield",
        subtitle: "Całkowicie ukryty",
        description: "Cel ma całkowitą osłonę, jeśli jest całkowicie ukryty przez przeszkodę",
        reference: "PHB, pg. 196.",
        bullets: [
            "Cel z całkowitą osłoną <b>nie może być bezpośrednio namierzony</b> przez atak lub zaklęcie, chociaż niektóre zaklęcia mogą dosięgnąć takiego celu, włączając go w obszar działania.",
            "Jeśli cel znajduje się za kilkoma źródłami osłony, zastosowanie ma tylko najbardziej ochronny stopień osłony"
        ]
    }
]
