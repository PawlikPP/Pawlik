data_action = [
    {
        title: "Atak",
        icon: "crossed-swords",
        subtitle: "Atak wręcz lub dystansowy",
        description: "Wykonaj atak wręcz lub dystansowy swoją bronią.",
        reference: "PHB, pgs. 192,194-195.",
        bullets: [
            "Niektóre cechy, takie jak <i>Dodatkowy Atak</i> wojownika, pozwalają na wykonanie więcej niż jednego ataku za pomocą tej akcji. Każdy z tych ataków jest osobnym rzutem i może być wymierzony w różne stworzenia. Możesz poruszać się pomiędzy tymi atakami.",
            "Kiedy atakujesz lekką bronią białą, możesz użyć akcji dodatkowej, aby zaatakować drugą ręką (patrz akcja bonusowa <i>Atak z drugiej ręki</i>).",
            "Możesz zamienić jeden ze swoich ataków w walce wręcz na <i>Chwyt</i> or a <i>Pchnięcie</i>.",
            "Niektóre warunki dają przewagę przy ataku: ataki przeciwko celom oślepionym, sparaliżowanym, skamieniałym, skrępowanym, ogłuszonym lub nieprzytomnym; ataki wręcz przeciwko celom leżącym; ataki niewidzialnych lub ukrytych napastników.",
            "Niektóre warunki wpływają niekorzystnie na atak: ataki przeciwko niewidzialnym lub ukrytym celom; ataki dystansowe przeciwko podatnym celom; ataki przez oślepionych, przestraszonych, zatrutych lub skrępowanych napastników."
        ]
    },
    {
        title: "Chwyt",
        icon: "grab",
        subtitle: "Specjalny atak wręcz",
        description: "Próba złapania stworzenia lub siłowania się z nim",
        reference: "PHB, pg. 195.",
        bullets: [
            "Możesz użyć akcji <i>Atak</i>, aby wykonać specjalny atak w walce wręcz, chwyt. Jeśli możesz wykonać kilka ataków za pomocą akcji ataku, ten atak zastępuje jeden z nich.",
            "Cel twojego chwytu nie może być większy od ciebie o więcej niż jeden rozmiar i musi znajdować się w twoim zasięgu.",
            "Używając co najmniej jednej wolnej ręki, próbujesz chwycić cel, wykonując test chwytania, test Siły (Atletyka) zakwestionowany przez test Siły (Atletyka) lub Zręczności (Akrobatyka) celu (cel wybiera umiejętność, której chce użyć).",
            "Jeśli ci się powiedzie, poddajesz cel warunkowi związania (jego prędkość zostaje ustawiona na 0)."
        ]
    },
    {
        title: "Pchnięcie",
        icon: "hand",
        subtitle: "Specjalny atak wręcz",
        description: "Popchnij stworzenie, aby powalić je na ziemię lub odepchnąć od siebie",
        reference: "PHB, pg. 195.",
        bullets: [
            "Używając akcji <i>Atak</i>, możesz wykonać specjalny atak w walce wręcz, aby popchnąć stworzenie. Jeśli możesz wykonać kilka ataków za pomocą akcji Atak, ten atak zastępuje jeden z nich.",
            "Cel pchnięcia nie może być większy od ciebie o więcej niż jeden rozmiar i musi znajdować się w twoim zasięgu.",
            "Wykonujesz test Siły (Atletyka) podważony przez test Siły (Atletyka) lub Zręczności (Akrobatyka) celu (cel wybiera umiejętność, której chce użyć).",
            "Jeśli wygrasz to starcie, powalisz cel na ziemię lub odepchniesz go na 5 stóp od siebie."
        ]
    },
    {
        title: "Rzucenie zaklęcia",
        icon: "magic-swirl",
        subtitle: "Czas rzucania: 1 akcja",
        description: "Rzuca zaklęcie z czasem rzucania wynoszącym 1 akcję",
        reference: "PHB, pg. 192.",
        bullets: [
            "Nie możesz rzucić zaklęcia za pomocą swojej akcji i innego zaklęcia za pomocą swojej akcji bonusowej w tej samej turze, chyba że akcja jest używana do rzucenia zaklęcia.",
            "Cel zaklęcia musi znajdować się w jego zasięgu. Aby namierzyć cel, musisz mieć do niego wyraźną drogę, więc nie może on znajdować się za całkowitą osłoną.",
            "Zaklęcia z komponentami materialnymi nie zużywają materiału, chyba że jest to wyraźnie zaznaczone. Jeśli nie podano kosztu materiału, można założyć, że jest on znikomy, a materiał jest po prostu dostępny w woreczku z komponentami.",
            "Niektóre zaklęcia wymagają utrzymania koncentracji, aby ich magia pozostała aktywna. Jeśli stracisz koncentrację, takie zaklęcie wygaśnie. Tracisz koncentrację nad zaklęciem, jeśli rzucisz inne zaklęcie wymagające koncentracji lub gdy zostaniesz obezwładniony. Za każdym razem, gdy otrzymasz obrażenia, musisz wykonać rzut obronny na Konstytucję, aby utrzymać koncentrację. Współczynnik DC wynosi 10 lub połowę otrzymanych obrażeń, w zależności od tego, która z tych wartości jest wyższa."
        ]
    },
    {
        title: "Sprint",
        icon: "sprint",
        subtitle: "Podwójna prędkość ruchu",
        description: "Dodatkowy ruch w bieżącej turze",
        reference: "PHB, pg. 192.",
        bullets: [
            "Wzrost jest równy prędkości po zastosowaniu wszelkich modyfikatorów."
        ]
    },
    {
        title: "Odstąpienie",
        icon: "journey",
        subtitle: "Zapobieganie atakom okazjonalnym",
        description: "Twój ruch nie prowokuje ataków okazjonalnych do końca tury.",
        reference: "PHB, pg. 192.",
        bullets: [
        ]
    },
    {
        title: "Unik",
        icon: "aura",
        subtitle: "Zwiększenie obrony",
        description: "Skup się całkowicie na unikaniu ataków",
        reference: "PHB, pg. 192.",
        bullets: [
            "Do początku twojej następnej tury, każdy rzut ataku wykonany przeciwko tobie ma wadę, jeśli widzisz atakującego, a ty wykonujesz rzuty obronne na Zręczność z przewagą.",
            "Utracisz tę korzyść, jeśli zostaniesz <i>obezwładniony</i> lub jeśli twoja prędkość spadnie do 0."
        ]
    },
    {
        title: "Ucieczka",
        icon: "manacles",
        subtitle: "Uniknięcie chwytu",
        description: "Ucieczka przed chwytem",
        reference: "PHB, pg. 195.",
        bullets: [
            "Aby wyrwać się z uścisku, musisz udanie wykonać test Siły (Atletyka) lub Zręczności (Akrobatyka), który zostanie zakwestionowany przez test Siły (Atletyka) chwytającego.",
            "Uwolnienie się z innych ograniczeń (takich jak kajdany) może wymagać testu Zręczności lub Siły, zgodnie z wymaganiami danego ograniczenia."
        ]
    },
    {
        title: "Pomoc",
        icon: "telepathy",
        subtitle: "Zapewnij sojusznikowi przewagę",
        description: "Zapewnia sojusznikowi przewagę podczas sprawdzania umiejętności lub ataku.",
        reference: "PHB, pg. 192.",
        bullets: [
            "Cel zyskuje przewagę przy następnym teście umiejętności, który wykona, aby wykonać zadanie, w którym pomagasz.",
            "Alternatywnie, cel zyskuje przewagę przy następnym rzucie ataku przeciwko stworzeniu znajdującemu się w odległości 5 stóp od ciebie.",
            "Przewaga trwa do początku następnej tury."
        ]
    },
    {
        title: "Użycie Obiektu",
        icon: "snatch",
        subtitle: "Korzystanie z umiejętności specjalnych",
        description: "Interakcja z drugim obiektem lub użycie specjalnych zdolności obiektu.",
        reference: "PHB, pg. 193.",
        bullets: [
            "Podczas swojej tury możesz bezpłatnie wejść w interakcję z jednym obiektem (np. wyciągnąć broń lub otworzyć drzwi). Jeśli chcesz wejść w interakcję z drugim obiektem, użyj tej akcji.",
            "Gdy przedmiot wymaga akcji użytkownika, również wykonuje on tę akcję."
        ]
    },
    {
        title: "Użycie Tarczy",
        icon: "round-shield",
        subtitle: "Wyposażenie lub odłączenie tarczy",
        description: "Wyposażenie lub odłączenie tarczy",
        reference: "PHB, pgs. 144-146.",
        bullets: [
            "Wyposażenie lub odłączenie tarczy zawsze wymaga akcji.",
            "Zakładanie i zdejmowanie pancerza trwa kilka minut."
        ]
    },
    {
        title: "Ukrycie",
        icon: "hood",
        subtitle: "Próba ukrycia",
        description: "Próba ukrycia",
        reference: "PHB, pg. 192.",
        bullets: [
            "Nie możesz ukryć się przed stworzeniem, które cię widzi. Musisz mieć całkowitą osłonę, znajdować się w mocno zasłoniętym obszarze, być niewidzialny lub w inny sposób blokować pole widzenia wroga.",
            "Jeśli robisz hałas (np. krzycząc ostrzeżenie lub przewracając wazon), zdradzasz swoją pozycję.",
            "Kiedy próbujesz się ukryć, wykonaj test Zręczności (Skradanie się) i zanotuj jego wynik. Dopóki nie zostaniesz odkryty lub nie przestaniesz się ukrywać, suma tego testu jest kwestionowana przez test Mądrości (Spostrzegawczość) każdej istoty, która aktywnie szuka oznak twojej obecności.",
            "Stworzenie zauważa cię, nawet jeśli nie szuka, chyba że twój test Skradania się jest wyższy niż jego pasywna Percepcja.",
            "Poza walką, możesz również użyć testu Zręczności (Skradanie się) do takich czynności jak ukrywanie się przed wrogami, przemykanie obok strażników, wymykanie się niezauważonym lub podkradanie się do kogoś niezauważonym lub niesłyszanym."
        ]
    },
    {
        title: "Wyszukiwanie",
        icon: "magnifying-glass",
        subtitle: "Próba dostrzeżenia czegoś",
        description: "Poświęć swoją uwagę na znalezienie czegoś",
        reference: "PHB, pg. 193.",
        bullets: [
            "W zależności od charakteru poszukiwań, MG może kazać ci wykonać test Mądrości (Percepcja) lub Inteligencji (Śledztwo)."
        ]
    },
    {
        title: "Gotowość",
        icon: "stopwatch",
        subtitle: "Wybierz wyzwalacz i działanie",
        description: "Wybierz czynnik wyzwalający i reakcję",
        reference: "PHB, pg. 193.",
        bullets: [
            "Najpierw zdecyduj, jakie możliwe okoliczności wywołają twoją reakcję.",
            "Następnie wybierasz działanie, które podejmiesz w odpowiedzi na ten wyzwalacz, lub decydujesz się przyspieszyć w odpowiedzi na niego.",
            "Gdy nastąpi wyzwalacz, możesz podjąć reakcję zaraz po jego zakończeniu lub zignorować wyzwalacz.",
            "Kiedy przygotowujesz zaklęcie, rzucasz je jak zwykle, ale zatrzymujesz jego energię, którą uwalniasz wraz z reakcją, gdy następuje wyzwalacz. Aby przygotować zaklęcie, czas jego rzucenia musi wynosić 1 akcję, a utrzymanie magii zaklęcia wymaga koncentracji"
        ]
    },
    {
        title: "Użycie funkcji klasy",
        icon: "embrassed-energy",
        subtitle: "Niektóre funkcje wykorzystują akcje",
        description: "Użycie cechy rasowej lub klasowej, która wykorzystuje akcję",
        reference: "Więcej informacji można znaleźć na stronie klasy.",
        bullets: [

        ]
    },
    {
        title: "Stabilizacja",
        icon: "first-aid",
        subtitle: "Udzielanie pierwszej pomocy umierającemu",
        description: "Sprawia, że umierająca istota nie musi wykonywać rzutów ratunkowych na śmierć.",
        reference: "PHB, pg. 197.",
        bullets: [
            "Wykonaj test Mądrości (Medycyna) z DC 10",
            "W przypadku sukcesu, istota jest stabilna i nie musi już wykonywać rzutów ratunkowych przed śmiercią",
            "Stabilna istota odzyskuje 1 punkt wytrzymałości po 1d4 godzinach"
        ]
    },
    {
        title: "Improwizacja",
        icon: "juggler",
        subtitle: "Wszelkie działania spoza tej listy",
        description: "Wykonaj dowolną czynność, jaką możesz sobie wyobrazić",
        reference: "PHB, pg. 193.",
        bullets: [
            "Kiedy opisujesz akcję, która nie jest opisana w żadnym innym miejscu zasad, MG mówi ci, czy ta akcja jest możliwa i jaki rodzaj rzutu musisz wykonać, jeśli w ogóle, aby określić sukces lub porażkę."
        ]
    }
]
