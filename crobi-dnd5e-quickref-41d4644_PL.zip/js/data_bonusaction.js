data_bonusaction = [
    {
        title: "Atak drugą ręką",
        icon: "crossed-swords",
        subtitle: "Użyj z akcją Atak",
        description: "Atakuj drugą ręką",
        reference: "PHB, pgs. 192,194-195.",
        bullets: [
            "Można jej użyć tylko wtedy, gdy wykonasz akcję <i>Ataku</i> i zaatakujesz lekką bronią do walki wręcz trzymaną w jednej ręce.",
            "Wykonaj pojedynczy atak inną lekką bronią do walki wręcz, którą trzymasz w drugiej ręce.",
            "Nie dodajesz swojego modyfikatora umiejętności do obrażeń ataku premiowego, chyba że modyfikator ten jest ujemny.",
            "Jeśli któraś z broni ma właściwość rzucania, możesz nią rzucić, zamiast wykonywać nią atak wręcz."
        ]
    },
    {
        title: "Rzucenie zaklęcie",
        icon: "magic-swirl",
        subtitle: "Czas rzucania: 1 akcja bonusowa",
        description: "Rzuca zaklęcie z czasem rzucania wynoszącym 1 dodatkową akcję",
        reference: "PHB, pg. 192.",
        bullets: [
            "Nie możesz rzucić zaklęcia za pomocą swojej akcji i innego zaklęcia za pomocą swojej akcji bonusowej w tej samej turze, chyba że akcja jest używana do rzucenia cantripa.",
            "Więcej informacji można znaleźć w akcji <i>Rzuć zaklęcie</i>."
        ]
    },
    {
        title: "Użycie funkcji klasy",
        icon: "embrassed-energy",
        subtitle: "Niektóre funkcje wykorzystują akcje bonusowe",
        description: "Użycie cechy rasowej lub klasowej, która wykorzystuje dodatkową akcję.",
        reference: "Więcej informacji można znaleźć na stronie klasy.",
        bullets: [

        ]
    }
]
