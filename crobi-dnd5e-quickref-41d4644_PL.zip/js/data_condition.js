data_condition = [
    {
        title: "Oślepienie",
        icon: "one-eyed",
        subtitle: "Nie widzisz",
        description: "Nie widzisz",
        reference: "PHB, pg. 290.",
        bullets: [
            "Automatycznie oblewasz każdy test umiejętności wymagający wzroku.",
            "Masz gorsze wyniki rzutów ataku.",
            "Ataki przeciwko tobie mają przewagę."
        ]
    },
    {
        title: "Zauroczenie",
        icon: "smitten",
        subtitle: "Jesteś zauroczony",
        description: "Jesteś zauroczony przez inną istotę",
        reference: "PHB, pg. 290.",
        bullets: [
            "Nie możesz atakować swojego zaklinacza ani celować w niego za pomocą szkodliwych zdolności lub efektów magicznych.",
            "Twój zaklinacz ma przewagę w testach umiejętności interakcji społecznych z tobą."
        ]
    },
    {
        title: "Ogłuszonie",
        icon: "elf-ear",
        subtitle: "Nie słyszysz",
        description: "Nie słyszysz",
        reference: "PHB, pg. 290.",
        bullets: [
            "Automatycznie oblewasz każdy test umiejętności wymagający słuchu."
        ]
    },
    {
        title: "Zmęczenie",
        icon: "crawl",
        subtitle: "Jesteś wyczerpany",
        description: "Wyczerpanie jest mierzone w sześciu poziomach",
        reference: "PHB, pg. 291.",
        bullets: [
            "<table><tr><th>Poziom</th><th></th><th></th><th style='text-align:left'>Efekt</th></tr><tr><td>1</td><td></td><td></td><td>Niekorzystny wynik testów umiejętności</td></tr><tr><td>2</td><td></td><td></td><td>Szybkość zmniejszona o połowę</td></tr><tr><td>3</td><td></td><td></td><td>Ujemny wpływ na rzuty ataku i rzuty obronne</td></tr><tr><td>4</td><td></td><td></td><td>Maksymalna liczba punktów wytrzymałości zmniejszona o połowę</td></tr><tr><td>5</td><td></td><td></td><td>Prędkość zredukowana do 0</td></tr><tr><td>6</td><td></td><td></td><td>Śmierć</td></tr></table>",
            "Odczuwasz efekt aktualnego poziomu wyczerpania, a także wszystkich niższych poziomów.",
            "Ukończenie długiego odpoczynku zmniejsza poziom wyczerpania o 1, pod warunkiem, że spożyto również trochę jedzenia i picia.",
            "Ponadto wskrzeszenie z martwych zmniejsza poziom wyczerpania istoty o 1."
        ]
    },
    {
        title: "Przestraszenie",
        icon: "sharp-smile",
        subtitle: "Jesteś przerażony",
        description: "Jesteś przerażony",
        reference: "PHB, pg. 290.",
        bullets: [
            "Gdy źródło strachu znajduje się w zasięgu wzroku, masz gorsze wyniki testów umiejętności i rzutów ataku.",
            "Nie możesz dobrowolnie zbliżyć się do źródła swojego strachu."
        ]
    },
    {
        title: "Złapanie",
        icon: "grab",
        subtitle: "Zostałeś złapany",
        description: "Zostałeś złapany",
        reference: "PHB, pg. 290.",
        bullets: [
            "Szybkość wynosi 0 i nie można korzystać z żadnych premii do szybkości.",
            "Warunek kończy się, jeśli chwytający zostanie obezwładniony.",
            "Warunek ten kończy się również, jeśli zostaniesz usunięty z zasięgu swojego chwytającego."
        ]
    },
    {
        title: "Ubezwłasnowolnienie",
        icon: "internal-injury",
        subtitle: "Nie można podejmować działań ani reakcji",
        description: "Nie można podejmować działań ani reakcji",
        reference: "PHB, pg. 290.",
        bullets: [
        ]
    },
    {
        title: "Niewidzialność",
        icon: "invisible",
        subtitle: "Nie można cię zobaczyć",
        description: "Nie można cię zobaczyć bez pomocy magii lub specjalnego zmysłu",
        reference: "PHB, pg. 291.",
        bullets: [
            "Aby się ukryć, jesteś mocno zasłonięty.",
            "Wciąż możesz zostać wykryty przez hałas, który wytwarzasz lub ślady, które pozostawiasz.",
            "Masz przewagę w rzutach ataku.",
            "Rzuty ataku przeciwko tobie są niekorzystne."
        ]
    },
    {
        title: "Paraliż",
        icon: "internal-injury",
        subtitle: "Jesteś sparaliżowany",
        description: "Nic nie możesz zrobić",
        bullets: [
            "Jesteś ubezwłasnowolniony i nie możesz się poruszać ani mówić.",
            "Ataki przeciwko tobie mają przewagę.",
            "Każdy atak, który cię trafi, jest trafieniem krytycznym, jeśli atakujący znajduje się w promieniu 5 stóp od ciebie.",
            "Automatycznie nie udają ci się rzuty obronne na Siłę i Zręczność."
        ]
    },
    {
        title: "Skamieniałość",
        icon: "stone-pile",
        subtitle: "Zostajesz zamieniony w kamień",
        description: "Zostajesz przekształcony, wraz z wszelkimi niemagicznymi przedmiotami, które nosisz lub masz przy sobie, w stałą nieożywioną substancję (zwykle kamień).",
        reference: "PHB, pg. 291.",
        bullets: [
            "Twoja waga wzrasta dziesięciokrotnie i przestajesz się starzeć.",
            "Jesteś ubezwłasnowolniony, nie możesz się poruszać ani mówić i jesteś nieświadomy swojego otoczenia.",
            "Ataki przeciwko tobie mają przewagę.",
            "Automatycznie nie udają ci się rzuty obronne na Siłę i Zręczność.",
            "Posiadasz odporność na wszystkie obrażenia.",
            "Jesteś odporny na trucizny i choroby, choć trucizna lub choroba znajdująca się już w twoim organizmie zostaje jedynie zawieszona, a nie zneutralizowana."
        ]
    },
    {
        title: "Zatrucie",
        icon: "deathcab",
        subtitle: "Zostałeś otruty",
        description: "Zostałeś otruty",
        reference: "PHB, pg. 292.",
        bullets: [
            "Masz niekorzystny wpływ na rzuty ataku i testy umiejętności."
        ]
    },
    {
        title: "Podatność",
        icon: "crawl",
        subtitle: "Jesteś podatny",
        description: "Jesteś podatny",
        reference: "PHB, pg. 292.",
        bullets: [
            "Jedyną opcją ruchu jest czołganie się, chyba że wstaniesz.",
            "Rzuty ataku są niekorzystne.",
            "Rzuty ataku przeciwko tobie mają przewagę, jeśli atakujący znajduje się w promieniu 5 stóp od ciebie, w przeciwnym razie rzut ataku ma wadę."
        ]
    },
    {
        title: "Ograniczenie",
        icon: "imprisoned",
        subtitle: "Jesteś skrępowany",
        description: "Jesteś skrępowany",
        reference: "PHB, pg. 292.",
        bullets: [
            "Szybkość wynosi 0 i nie można korzystać z żadnych premii do szybkości.",
            "Rzuty ataku są niekorzystne.",
            "Ataki przeciwko tobie mają przewagę.",
            "Rzuty obronne na zręczność są niekorzystne."
        ]
    },
    {
        title: "Ogłuszenie",
        icon: "internal-injury",
        subtitle: "Jesteś ogłuszony",
        description: "Jesteś ogłuszony",
        reference: "PHB, pg. 292.",
        bullets: [
            "Jesteś ubezwłasnowolniony, nie możesz się poruszać i możesz mówić tylko niepewnie.",
            "Ataki przeciwko tobie mają przewagę.",
            "Automatycznie nie udają ci się rzuty obronne na Siłę i Zręczność."
        ]
    },
    {
        title: "Nieprzytomność",
        icon: "coma",
        subtitle: "Jesteś nieprzytomny",
        description: "Jesteś nieprzytomny",
        reference: "PHB, pg. 292.",
        bullets: [
            "Jesteś ubezwłasnowolniony, nie możesz się poruszać ani mówić i jesteś nieświadomy swojego otoczenia.",
            "Upuszczasz wszystko, co trzymasz i padasz na ziemię.",
            "Ataki przeciwko tobie mają przewagę.",
            "Każdy atak, który cię trafi, jest trafieniem krytycznym, jeśli atakujący znajduje się w promieniu 5 stóp od ciebie.",
            "Automatycznie nie udają ci się rzuty obronne na Siłę i Zręczność.",
        ]
    },
    {
        title: "Umieranie",
        icon: "dead-head",
        subtitle: "Umierasz",
        description: "Liczba twoich punktów życia spadła do zera i umierasz.",
        reference: "PHB, pg. 197.",
        bullets: [
            "Jeśli w wyniku obrażeń, które nie zabiły cię, twoja liczba punktów życia spadnie do 0, tracisz przytomność i umierasz.",
            "Jeśli otrzymasz jakiekolwiek uzdrowienie, natychmiast odzyskasz przytomność i nie będziesz już umierać.",
            "Umierając, na początku każdej swojej tury wykonujesz rzut obronny przed śmiercią. Rzuć d20 i nie dodawaj żadnych modyfikatorów.",
            "Wynik 10 lub wyższy to sukces, 9 lub niższy to porażka.",
            "Po trzecim sukcesie stajesz się stabilny.",
            "Trzecia porażka oznacza śmierć.",
            "Wyrzucenie 1 oznacza dwie porażki.",
            "Wyrzucenie 20 powoduje natychmiastowe odzyskanie 1 punktu wytrzymałości.",
            "Możesz także zostać ustabilizowany przez sojusznika, który wykona akcję Stabilizacji i zda test Mądrości (Medycyna) o DC10.",
            "Po ustabilizowaniu się, odzyskujesz 1 punkt wytrzymałości po 1d4 godzinach."
        ]
    }
]
