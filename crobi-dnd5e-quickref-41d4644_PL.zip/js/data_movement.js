data_movement = [
    {
        title: "Ruch",
        icon: "run",
        subtitle: "Koszt: 5 stóp za 5 stóp",
        description: "Koszt ruchu: 5 stóp za każde przemieszczone 5 stóp",
        reference: "PHB, pg. 190.",
        bullets: [
            "Jeśli masz więcej niż jedną prędkość, np. prędkość chodzenia i prędkość latania, możesz przełączać się między prędkościami podczas ruchu. Za każdym razem, gdy się przełączasz, odejmij odległość, którą już przebyłeś, od nowej prędkości.",
            "Możesz poruszać się w przestrzeni, w której nie znajduje się wroga istota.",
            "Możesz poruszać się w przestrzeni wrogiej istoty tylko wtedy, gdy jest ona co najmniej dwa rozmiary większa lub mniejsza od ciebi",
            "Przestrzeń innej istoty jest dla ciebie trudnym terene",
            "Niezależnie od tego, czy dana istota jest przyjacielem, czy wrogiem, nie możesz dobrowolnie zakończyć swojego ruchu na jej obszarze."
        ]
    },
    {
        title: "Wspinaczka",
        icon: "crags",
        subtitle: "Koszt: 10 stóp na 5 stóp",
        description: "Koszt ruchu: 10 stóp na każde pokonane 5 stóp",
        reference: "PHB, pg. 182.",
        bullets: [
            "Może wymagać sprawdzenia Siły (Atletyka), jeśli wspinaczka jest trudna."
        ]
    },
    {
        title: "Pływanie",
        icon: "at-sea",
        subtitle: "Koszt: 10 stóp na 5 stóp",
        description: "Koszt ruchu: 10 stóp za każde przepłynięte 5 stóp",
        reference: "PHB, pg. 182.",
        bullets: [
            "Może wymagać sprawdzenia Siły (Atletyka), jeśli pływanie jest trudne."
        ]
    },
    {
        title: "Upadek",
        icon: "falling",
        subtitle: "Koszt: 0 stóp",
        description: "Koszt ruchu: 0 stóp (za darmo)",
        reference: "PHB, pgs. 190-191,292.",
        bullets: [
            "Możesz upaść na ziemię bez używania prędkości",
            "Aby poruszać się w pozycji leżącej, musisz się czołgać lub użyć magii, takiej jak teleportacja",
            "Upadek z pozycji leżącej dodaje warunek <i>Upadek</i> (ataki wręcz przeciwko tobie mają przewagę, ataki dystansowe przeciwko tobie mają wadę, twoje własne ataki mają wadę)."
        ]
    },
    {
        title: "Czołganie się",
        icon: "crawl",
        subtitle: "Koszt: 10 stóp na 5 stóp",
        description: "Koszt ruchu: 10 stóp na 5 stóp czołgania się",
        reference: "PHB, pg. 182.",
        bullets: [

        ]
    },
    {
        title: "Wstawanie",
        icon: "strong",
        subtitle: "Koszt: połowa prędkości ruchu",
        description: "Koszt ruchu: połowa twojej prędkości",
        reference: "PHB, pg. 190-191.",
        bullets: [
            "Nie możesz wstać, jeśli nie masz wystarczająco dużo ruchu lub jeśli twoja prędkość wynosi 0."
        ]
    },
    {
        title: "Wysoki skok",
        icon: "wingfoot",
        subtitle: "Koszt: 5 stóp za 5 stóp",
        description: "Koszt ruchu: 5 stóp za skok na 5 stóp",
        
        reference: "PHB, pg. 182.",
        bullets: [
            "Skaczesz w powietrze na odległość równą <b>3 + twój modyfikator Siły</b>, jeśli bezpośrednio przed skokiem przemieścisz się pieszo o co najmniej 10 stóp.",
            "Podczas skoku wzwyż na stojąco można skoczyć tylko na połowę tej odległości.",
            "Podczas skoku możesz wyciągnąć ręce do połowy swojej wysokości.",
            "W niektórych okolicznościach MG może pozwolić ci na wykonanie testu Siły (Atletyka), aby skoczyć wyżej niż normalnie."
        ]
    },
    {
        title: "Skok w dal",
        icon: "wingfoot",
        subtitle: "Koszt: 5 stóp za 5 stóp",
        description: "Koszt ruchu: 5 stóp za skok na 5 stóp",
        reference: "PHB, pg. 182.",
        bullets: [
            "Pokonujesz liczbę stóp równą twojej <b>Sile</b>, jeśli bezpośrednio przed skokiem przejdziesz co najmniej 10 stóp.",
            "Kiedy wykonujesz skok w dal na stojąco, możesz przeskoczyć tylko połowę tej odległości",
            "Może wymagać testu Siły (Atletyka) o DC 10, aby pokonać niską przeszkodę (nie wyższą niż jedna czwarta odległości skoku). W przypadku nieudanego testu trafiasz w przeszkodę.",
            "Może wymagać testu Zręczności (Akrobatyki) o DC 10, aby wylądować na nogach w trudnym terenie. W przypadku nieudanego testu wylądujesz na ziemi."
        ]
    },
    {
        title: "Improwizacja",
        icon: "juggler",
        subtitle: "Każdy wyczyn kaskaderski spoza tej listy",
        description: "Wykonaj dowolny ruch lub akrobację, jaką możesz sobie wyobrazić.",
        bullets: [
            "Kiedy opisujesz rodzaj ruchu, który nie został wyszczególniony w żadnym innym miejscu zasad, MG mówi ci, czy jest on możliwy i jaki rodzaj rzutu musisz wykonać, aby określić sukces lub porażkę."
        ]
    },
    {
        title: "Trudny teren",
        icon: "stone-pile",
        subtitle: "Modyfikator kosztu: +5 stóp na 5 stóp",
        reference: "PHB, pg. 182.",
        description: "Poruszanie się w trudnym terenie kosztuje dodatkowe 5 stóp za każde 5 stóp ruchu.",
        bullets: [
        ]
    },
    {
        title: "Chwytanie",
        icon: "grab",
        subtitle: "Modyfikator: prędkość zmniejszona o połowę",
        description: "Przeciągnij lub zabierz ze sobą złapaną istotę.",
        reference: "PHB, pg. 195.",
        bullets: [
            "Jeśli poruszasz się podczas chwytania innej istoty, twoja prędkość zmniejsza się o połowę, chyba że ta istota jest o dwa lub więcej rozmiarów mniejsza od ciebie.",
            "Zobacz akcję ataku, aby dowiedzieć się, jak chwycić stworzenie."
        ]
    }
]
