data_reaction = [
    {
        title: "Atak Okazyjny",
        icon: "crossed-swords",
        subtitle: "Wróg opuszcza twój zasięg",
        description: "Rzadko można beztrosko mijać wrogów, nie narażając się na niebezpieczeństwo",
        reference: "PHB, pg. 195.",
        bullets: [
            "Warunek: wroga istota, którą widzisz, opuszcza twój zasięg.",
            "Wykonaj jeden atak wręcz przeciwko prowokującemu stworzeniu.",
            "Atak przerywa ruch prowokującej istoty i następuje tuż przed opuszczeniem przez nią zasięgu.",
            "Stworzenia nie prowokują okazji do ataku, gdy się teleportują lub gdy ktoś lub coś poruszy je bez użycia ich ruchu, akcji lub reakcji."
        ]
    },
    {
        title: "Gotowość",
        icon: "stopwatch",
        subtitle: "Część akcji gotowości",
        description: "Wykonaj reakcję określoną przez twoją akcję gotowości.",
        reference: "PHB, pg. 193.",
        bullets: [
            "Warunek: określony przez twoje działanie <i>Gotowy</i>"
        ]
    },
    {
        title: "Rzucenie zaklęcia",
        icon: "magic-swirl",
        subtitle: "Czas rzucania: 1 reakcja.",
        description: "Rzuć zaklęcie o czasie rzucania równym 1 reakcji.",
        reference: "PHB, pg. 192.",
        bullets: [
            "Warunek: określony przez czar.",
            "Dla dalszych szczegółów, zobacz działanie <i>Rzucić zaklęcie</i>."
        ]
    }
]
